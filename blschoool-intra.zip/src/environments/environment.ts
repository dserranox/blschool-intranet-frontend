export const environment = {
  production: true,
  loginApiUrl: '/blschool-login/api',
  apiUrl: '/blschool-backend/api'
};
