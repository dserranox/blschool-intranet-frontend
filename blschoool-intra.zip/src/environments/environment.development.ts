export const environment = {
  production: false,
  loginApiUrl: '/blschool-login/api',
  apiUrl: '/blschool-backend/api'
};
