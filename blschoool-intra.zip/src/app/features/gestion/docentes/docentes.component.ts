import { Component, inject, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DocentesService, Docente } from '../../../core/services/docentes.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-docentes',
  imports: [CommonModule, FormsModule],
  templateUrl: './docentes.component.html',
  styleUrl: './docentes.component.css'
})
export class DocentesComponent implements OnInit {
  private docentesService = inject(DocentesService);
  authService = inject(AuthService);

  searchTerm = '';
  docentes = signal<Docente[]>([]);
  filteredDocentes = signal<Docente[]>([]);

  ngOnInit() {
    this.cargarDocentes();
  }

  cargarDocentes() {
    this.docentesService.listar().subscribe({
      next: (data) => {
        this.docentes.set(data);
        this.filtrarDocentes();
      }
    });
  }

  filtrarDocentes() {
    const term = this.searchTerm.trim().toLowerCase();
    if (!term) {
      this.filteredDocentes.set(this.docentes());
      return;
    }
    this.filteredDocentes.set(
      this.docentes().filter(d =>
        (d.nombres?.toLowerCase().includes(term)) ||
        (d.apellidos?.toLowerCase().includes(term))
      )
    );
  }

  puedeEditar(docente: Docente): boolean {
    if (this.authService.isAdmin()) return true;
    return docente.id === this.authService.personaId();
  }

  puedeEliminar(docente: Docente): boolean {
    return this.authService.isAdmin();
  }

  ver(docente: Docente) {
    // TODO: implementar vista detalle
  }

  editar(docente: Docente) {
    // TODO: implementar edición
  }

  desactivar(docente: Docente) {
    this.docentesService.desactivar(docente.id).subscribe({
      next: () => this.cargarDocentes()
    });
  }

  activar(docente: Docente) {
    this.docentesService.activar(docente.id).subscribe({
      next: () => this.cargarDocentes()
    });
  }
}
