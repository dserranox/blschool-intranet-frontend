import { Component } from '@angular/core';

@Component({
  selector: 'app-alumnos',
  template: `<h2>Hello Alumnos</h2>`,
})
export class AlumnosComponent {}
