import { Component } from '@angular/core';

@Component({
  selector: 'app-comisiones',
  template: `<h2>Hello Comisiones</h2>`,
})
export class ComisionesComponent {}
