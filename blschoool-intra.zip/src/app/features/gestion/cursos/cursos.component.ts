import { Component } from '@angular/core';

@Component({
  selector: 'app-cursos',
  template: `<h2>Hello Cursos</h2>`,
})
export class CursosComponent {}
